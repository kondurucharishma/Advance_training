package problem_statement1_3;

public class Book2 {
	public void createBooks() {
		Book b[] = new Book[2];		 
	      b[1] = new Book("Java Programing ", 350.50);
	      b[2] = new Book("Let Us C", 200.00);
	      for(int i = 0; i<b.length; i++) {
		         b[i].display();
		         System.out.println(" ");
	      }
	}
	public void showBooks() {
		  	createBooks();
	}

	public static void main(String[] args) {
		Book2 c1 = new Book2();  
		c1.showBooks();
		}

}
