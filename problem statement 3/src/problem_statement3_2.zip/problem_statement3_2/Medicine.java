package problem_statement3_2;

public class Medicine {
	
		
	public void displayLabel(){
		System.out.println("Company :Peoples pharma ");
		System.out.println("Address :Pune");
		}
}
	
	class Tablet extends Medicine{	 
	public void displayLabel(){
		System.out.println("Do not explosure to direct sunlight"); 
		System.out.println("store in a cool dry place");
		}
	}
	class Syrup extends Medicine{
		public void displayLabel(){
		System.out.println("Shake well before use");
		}
		}
	class Ointment extends Medicine{
		public void displayLabel(){
		System.out.println("For external use only");
	}	
	
}