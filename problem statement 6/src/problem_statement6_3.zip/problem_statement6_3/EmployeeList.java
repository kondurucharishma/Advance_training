package problem_statement6_3;
import java.util.*;

public class EmployeeList {
	private static final Employee[] v= null;
	
	public static void main(String[] args) {
		Vector<Employee> v = addInput();
		display(v);
	}
	private static Vector<Employee> addInput() {
		
		return null;
	}
	private static void display(Vector<Employee> v) {
		
	}
	
	public static Vector<Employee> main1() {
	//public static void main1(String[] args) {

		Employee e1=new Employee(101, "siri", "hyderabad");
		Employee e2=new Employee(200, "pooja", "banglore");
		Employee e3=new Employee(351, "vyshu", "chennai");
		Vector<Employee> v =new Vector<Employee>();
		v.add(e1);
		v.add(e2);
		v.add(e3);
		return v;
		
	}
	public static void main2(String[] args) {
		
		for (Employee e: v) {
			System.out.println(e.getEmployeeNo() + " \t "+ e.getEmployeeName() + " \t "+ e.getAddress());
			
		}

	}

}
